<?php
include_once 'configuracion/conexion.php';
include_once('configuracion/sesion.php');
$pdo = Conexion::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$id_usuario = $_SESSION['usuario'];
$buscarusuario = 'SELECT * FROM usuario WHERE u_id = ?';
$q = $pdo->prepare($buscarusuario);
$q->execute(array($id_usuario));
$datousuario = $q->fetch(PDO::FETCH_ASSOC);
$usuarioid = $datousuario['u_id'];
$usuarioapellidos = $datousuario['u_apellidos'];
$usuarionombres = $datousuario['u_nombres'];
$usuariocontrasena = $datousuario['u_contrasena'];
$usuariocorreo = $datousuario['u_correo'];
$usuariorol = $datousuario['u_rol'];

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="shortcut icon" href="imagen/logo.png">
        <title>Sistema Educativo</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="fontawesome/css/all.css" rel="stylesheet" />
        <link href="css/bootstrap.min.css" rel="stylesheet" />
        <script src="fontawesome/js/all.js" crossorigin="anonymous"></script>
    </head>

    <style>
   
        .nav-link:hover{
            background-color: #ffc107;
            color: black;
        }
        .nav-link{
            color: white;
        }
    </style>