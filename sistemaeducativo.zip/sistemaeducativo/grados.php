        <?php include_once 'head.php' ?>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $accion = $_POST['accion'];
            if ($accion == 'agregar') {
                include_once 'gradoagregar.php';
            } else if ($accion == 'editar') {
                include_once 'gradoactualizar.php';
            } else if ($accion == 'eliminar') {
                $id = $_POST['id'];            
                 $sqlcantidad = "SELECT COUNT(*) FROM matricula WHERE m_gradofk = " . $id . "";
                 $query = $pdo->query($sqlcantidad);
                 $cantidad = $query->fetchColumn();

                 $sqlcantidadHo = "SELECT COUNT(*) FROM horarios WHERE h_gradofk = " . $id . "";
                 $queryho = $pdo->query($sqlcantidadHo);
                 $cantidadho = $queryho->fetchColumn();
                 if ($cantidad != 0) {
                    echo '<script language="javascript">alert("El grado tiene registro en Matricula");</script>';
                } elseif ($cantidadho != 0) {
                    echo '<script language="javascript">alert("El grado tiene registro en Horarios");</script>';
                } else {
                    $eliminar = "DELETE FROM grado WHERE g_id = ?";
                    $ejecutar = $pdo->prepare($eliminar);
                    $ejecutar->execute(array($id));
                    echo '<script language="javascript">alert("Eliminacion Exitosa");</script>';
                    Conexion::desconectar();
                }                
            }
        }
        ?>

        <body class="sb-nav-fixed">
            <?php include_once 'menuadmin.php' ?>


            <div id="layoutSidenav_content">
                <main>
                    <br/>
                    <div class="container">
                       

                       <!-- AGREGAR -->
                                <div class="modal fade" id="agregar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content ">
                                            <div class="modal-header text-white bg-warning">
                                                <h5 class="modal-title" id="agregar">Registrar Información</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form  ROLE="FORM" METHOD="POST" ACTION="">
                                                    <input type="hidden" class="form-control" id="accion" name="accion"  value="agregar">
                                                    <div class="row">

                                                        <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Grado</label>
                                                                <input type="text" class="form-control form-control-sm" id="grado" name="grado" placeholder="Grado Completo" required>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Aula</label>
                                                                <select class="form-select form-select-sm" id="aula" name="aula">
                                                            <?php
                                                            $aulas = 'SELECT * FROM aula ORDER BY a_id ASC;';
                                                            foreach ($pdo->query($aulas) as $dato) {  
                                                            ?>
                                                            <option value="<?php echo $dato['a_id'] ?>"> <?php echo $dato['a_nombre']." ".$dato['a_sesion'] ?></option>
                                                             <?php
                                                         }
                                                         ?>

                                                        </select>
                                                                </div>
                                                        </div>
                                                     

                                                        <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Sesión</label>
                                                                <input type="text" class="form-control form-control-sm" id="sesion" name="sesion" placeholder="Ingrese Sesión" required>
                                                            </div>
                                                        </div>
                                                           <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Vacante</label>
                                                                <input type="number" class="form-control form-control-sm" id="vacante" name="vacante" placeholder="Ingrese Vacantes" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        <div class="card">
                             <div class="card-header text-white bg-black">
                                <h5>GRADOS</h5>
                            </div>
                            <div class="card-header text-white bg-warning">
                                <strong>Tabla Grados &nbsp;&nbsp;<button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#agregar"><i class="fa-solid fa-plus"></i>&nbsp; Agregar</button></strong>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="display table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Grado</th>
                                            <th>Aula</th>
                                            <th>Sesión</th>
                                            <th>Vacante</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                           <th>Grado</th>
                                            <th>Aula</th>
                                            <th>Sesión</th>
                                            <th>Vacante</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $informacion = 'SELECT * FROM grado,aula WHERE g_aulafk = a_id ORDER BY g_id;';
                                        foreach ($pdo->query($informacion) as $dato) {
                                            ?>
                                            <tr>
                                                <td><?php echo $dato['g_grado'] ?></td>
                                                <td><?php echo $dato['a_nombre']." ".$dato['a_sesion'] ?></td>
                                                 <td><?php echo $dato['g_sesion'] ?></td>
                                                 <td><?php echo $dato['g_vacante'] ?></td>

                                        <td>
                                        <center><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEditar<?php echo $dato['g_id'] ?>" >
                                                <i class="fa-solid fa-pen"></i>
                                            </button></center> 
                                        <div class="modal fade" id="exampleModalEditar<?php echo $dato['g_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header text-white bg-warning">
                                                        <h5 class="modal-title">Actualizar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST" ACTION="">

                                                            <input type="hidden" class="form-control" id="accion" name="accion"  value="editar">
                                                            <input type="hidden" class="form-control form-control-sm" id="id" name="id" value = "<?php echo!empty($dato['g_id']) ? $dato['g_id'] : ''; ?>"  required>


                                                            <div class="row">                                                              
                                                                <div class="col-md-3"> 
                                                                    <div class="mb-3">
                                                                        <label class="form-label">Grado</label>
                                                                        <input type="text" class="form-control form-control-sm" id="grado" name="grado" placeholder="Grado Completo" value = "<?php echo!empty($dato['g_grado']) ? $dato['g_grado'] : ''; ?>" required>
                                                                    </div>
                                                                </div>

                                                                  <div class="col-md-3">
                                                                    <div class="mb-3" >
                                                                        <label class="form-label ">Aula</label>
                                                                        <select class="form-select form-select-sm" id="aula" name="aula">
                                                                            <?php
                                                                            $aulas = 'SELECT * FROM aula ORDER BY a_id ASC;';
                                                                            foreach ($pdo->query($aulas) as $datoaula) {
                                                                                if ($dato['g_aulafk'] == $datoaula['a_id']) {?>
                                                                                    <option value="<?php echo $datoaula['a_id'] ?>" selected> <?php echo $datoaula['a_nombre']." ".$datoaula['a_sesion'] ?></option>
                                                                                     <?php
                                                                                 } else {
                                                                                 ?>
                                                                                    <option value="<?php echo $datoaula['a_id'] ?>"> <?php echo $datoaula['a_nombre']." ".$datoaula['a_sesion'] ?></option>
                                                                                 <?php
                                                                             }
                                                                         }
                                                                         ?>
                                                                     

                                                        </select>
                                                    </div>
                                                </div>
                                                       

                                                        <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Sesión</label>
                                                                <input type="text" class="form-control form-control-sm" id="sesion" name="sesion" placeholder="Ingrese Sesión"  value = "<?php echo!empty($dato['g_sesion']) ? $dato['g_sesion'] : ''; ?>" required>
                                                            </div>
                                                        </div>

                                                         <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Vacante</label>
                                                                <input type="number" class="form-control form-control-sm" id="vacante" name="vacante" placeholder="Ingrese Nímero"  value = "<?php echo!empty($dato['g_vacante']) ? $dato['g_vacante'] : ''; ?>" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                </form>
                                            </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        <!-- ELIMININAR  -->
                                        <td>
                                        <center> <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEliminar<?php echo $dato['g_id'] ?>">
                                               <i class="fa-solid fa-trash"></i>
                                            </button></center>
                                        <div class="modal fade" id="exampleModalEliminar<?php echo $dato['g_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-warning text-white">
                                                        <h5 class="modal-title">Eliminar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST"  ACTION="">
                                                            <input type="hidden" class="form-control" id="accion" name="accion" value = "eliminar"  />
                                                            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo!empty($dato['g_id']) ? $dato['g_id'] : ''; ?>""  />
                                                            <h4>¿Desea eliminar la información de: <?php echo $dato['g_grado'] ?></h4>
                                                            <br/>
                                                            <div class="form__button__container" >
                                                                <button type="submit" class="btn btn-warning">Eliminar</button>
                                                            </div>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        </tr>
                                    <?php } ?>  


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

            


                </main>
                <?php include_once 'footer.php' ?>
            </div>
        </div>


        </body>
        </html>



        <script src="js/simple-datatables.js" crossorigin="anonymous"></script>
