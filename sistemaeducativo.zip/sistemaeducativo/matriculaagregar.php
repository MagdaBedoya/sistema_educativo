<?php


$identificacion = $_POST['identificacion'];
$apellidos = $_POST['apellidos'];
$nombres = $_POST['nombres'];
$sexo = $_POST['sexo'];
$grado = $_POST['grado'];

    $sqlcantidad = "SELECT COUNT(*) FROM matricula WHERE m_identificacion = " . $identificacion . "";
    $query = $pdo->query($sqlcantidad);
    $cantidad = $query->fetchColumn();

    if ($cantidad != 0) {
        echo '<script language="javascript">alert("El Estudiante ya se encuentra registrado");</script>';
    } else {

        $sql = "INSERT INTO matricula (m_identificacion, m_apellidos, m_nombres, m_gradofk, m_sexo) VALUES (?, ?, ?, ?, ?)";
        $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array($identificacion,strtoupper($apellidos), strtoupper($nombres), $grado, $sexo));
        echo '<script language="javascript">alert("Registro Exitoso");</script>';
        Conexion::desconectar();
    }

?>