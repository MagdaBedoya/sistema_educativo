<?php
$id = $_POST['id'];
$grado = $_POST['grado'];
$aula = $_POST['aula'];
$sesion = $_POST['sesion'];
$vacante = $_POST['vacante'];

$sql = "UPDATE grado SET g_grado = ?, g_aulafk = ?, g_sesion = ?, g_vacante = ? WHERE g_id = ? ";
$ejecutar = $pdo->prepare($sql);
$ejecutar->execute(array(strtoupper($grado), $aula,strtoupper($sesion), $vacante, $id));
echo '<script language="javascript">alert("Actualizacion exitosa");</script>';
Conexion::desconectar();
