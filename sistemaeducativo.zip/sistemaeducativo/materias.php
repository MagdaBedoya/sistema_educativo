        <?php include_once 'head.php' ?>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $accion = $_POST['accion'];
            if ($accion == 'agregar') {
                include_once 'materiaagregar.php';
            } else if ($accion == 'editar') {
                include_once 'materiaactualizar.php';
            } else if ($accion == 'eliminar') {

                $id = $_POST['id'];            
                 $sqlcantidad = "SELECT COUNT(*) FROM horarios WHERE h_materiafk = " . $id . "";
                 $query = $pdo->query($sqlcantidad);
                 $cantidad = $query->fetchColumn();
                
                 if ($cantidad != 0) {
                    echo '<script language="javascript">alert("La Materia tiene registro en Horario");</script>';
                } else {
                    $eliminar = "DELETE FROM materias WHERE m_id = ?";
                    $ejecutar = $pdo->prepare($eliminar);
                    $ejecutar->execute(array($id));
                    echo '<script language="javascript">alert("Eliminacion Exitosa");</script>';
                    Conexion::desconectar();
                }         
                
            }
        }
        ?>

        <body class="sb-nav-fixed">
            <?php include_once 'menuadmin.php' ?>


            <div id="layoutSidenav_content">
                <main>
                    <br/>
                    <div class="container">
                       

                       <!-- AGREGAR -->
                                <div class="modal fade" id="agregar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content ">
                                            <div class="modal-header text-white bg-warning">
                                                <h5 class="modal-title" id="agregar">Registrar Información</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form  ROLE="FORM" METHOD="POST" ACTION="">
                                                    <input type="hidden" class="form-control" id="accion" name="accion"  value="agregar">
                                                    <div class="row">

                                                        <div class="col-md-2"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Código</label>
                                                                <input type="text" class="form-control form-control-sm" id="codigo" name="codigo" placeholder="Codigo Completo" required>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Docente</label>
                                                                <select class="form-select form-select-sm" id="docente" name="docente">
                                                            <?php
                                                            $docentes = 'SELECT * FROM docente ORDER BY d_id ASC;';
                                                            foreach ($pdo->query($docentes) as $dato) {  
                                                            ?>
                                                            <option value="<?php echo $dato['d_id'] ?>"> <?php echo $dato['d_nombres']." ".$dato['d_apellidos'] ?></option>
                                                             <?php
                                                         }
                                                         ?>

                                                        </select>
                                                                </div>
                                                        </div>
                                                     

                                                        <div class="col-md-4"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Matería</label>
                                                                <input type="text" class="form-control form-control-sm" id="materia" name="materia" placeholder="Ingrese Materia" required>
                                                            </div>
                                                        </div>
                                                          
                                                    </div>
                                                    <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        <div class="card">
                             <div class="card-header text-white bg-black">
                                <h5>MATERIAS</h5>
                            </div>
                            <div class="card-header text-white bg-warning">
                                <strong>Tabla Grados &nbsp;&nbsp;<button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#agregar"><i class="fa-solid fa-plus"></i>&nbsp; Agregar</button></strong>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="display table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Código</th>
                                            <th>Docente</th>
                                            <th>Materia</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                           <th>Código</th>
                                            <th>Docente</th>
                                            <th>Materia</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $informacion = 'SELECT * FROM materias, docente WHERE m_docentefk = d_id ORDER BY m_id;';
                                        foreach ($pdo->query($informacion) as $dato) {
                                            ?>
                                            <tr>
                                                <td><?php echo $dato['m_codigo'] ?></td>
                                                <td><?php echo $dato['d_nombres']." ".$dato['d_apellidos'] ?></td>
                                                 <td><?php echo $dato['m_materia'] ?></td>

                                        <td>
                                        <center><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEditar<?php echo $dato['m_id'] ?>" >
                                                <i class="fa-solid fa-pen"></i>
                                            </button></center> 
                                        <div class="modal fade" id="exampleModalEditar<?php echo $dato['m_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header text-white bg-warning">
                                                        <h5 class="modal-title">Actualizar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST" ACTION="">

                                                            <input type="hidden" class="form-control" id="accion" name="accion"  value="editar">
                                                            <input type="hidden" class="form-control form-control-sm" id="id" name="id" value = "<?php echo!empty($dato['m_id']) ? $dato['m_id'] : ''; ?>"  required>


                                                            <div class="row">                                                              
                                                                <div class="col-md-2"> 
                                                                    <div class="mb-3">
                                                                        <label class="form-label">Código</label>
                                                                        <input type="text" class="form-control form-control-sm" id="codigo" name="codigo" placeholder="Código Completo" value = "<?php echo!empty($dato['m_codigo']) ? $dato['m_codigo'] : ''; ?>" required>
                                                                        <input type="hidden" class="form-control form-control-sm" id="codigoviejo" name="codigoviejo"  value = "<?php echo!empty($dato['m_codigo']) ? $dato['m_codigo'] : ''; ?>" required>
                                                                    </div>
                                                                </div>

                                                                  <div class="col-md-6">
                                                                    <div class="mb-3" >
                                                                        <label class="form-label ">Docente</label>
                                                                        <select class="form-select form-select-sm" id="docente" name="docente">
                                                                            <?php
                                                                            $docentes = 'SELECT * FROM docente ORDER BY d_id ASC;';
                                                                            foreach ($pdo->query($docentes) as $datodoc) {
                                                                                if ($dato['m_docentefk'] == $datodoc['d_id']) {?>
                                                                                    <option value="<?php echo $datodoc['d_id'] ?>" selected> <?php echo $datodoc['d_nombres']." ".$datodoc['d_apellidos'] ?></option>
                                                                                     <?php
                                                                                 } else {
                                                                                 ?>
                                                                                    <option value="<?php echo $datodoc['d_id'] ?>"> <?php echo $datodoc['d_nombres']." ".$datodoc['d_apellidos'] ?></option>
                                                                                 <?php
                                                                             }
                                                                         }
                                                                         ?>
                                                                     

                                                        </select>
                                                    </div>
                                                </div>
                                                       

                                                        <div class="col-md-4"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Matería</label>
                                                                <input type="text" class="form-control form-control-sm" id="materia" name="materia" placeholder="Ingrese Materia"  value = "<?php echo!empty($dato['m_materia']) ? $dato['m_materia'] : ''; ?>" required>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                </form>
                                            </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        <!-- ELIMININAR  -->
                                        <td>
                                        <center> <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEliminar<?php echo $dato['m_id'] ?>">
                                               <i class="fa-solid fa-trash"></i>
                                            </button></center>
                                        <div class="modal fade" id="exampleModalEliminar<?php echo $dato['m_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-warning text-white">
                                                        <h5 class="modal-title">Eliminar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST"  ACTION="">
                                                            <input type="hidden" class="form-control" id="accion" name="accion" value = "eliminar"  />
                                                            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo!empty($dato['m_id']) ? $dato['m_id'] : ''; ?>""  />
                                                            <h4>¿Desea eliminar la información de: <?php echo $dato['m_codigo'] ?>?</h4>
                                                            <br/>
                                                            <div class="form__button__container" >
                                                                <button type="submit" class="btn btn-warning">Eliminar</button>
                                                            </div>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        </tr>
                                    <?php } ?>  


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

            


                </main>
                <?php include_once 'footer.php' ?>
            </div>
        </div>


        </body>
        </html>



        <script src="js/simple-datatables.js" crossorigin="anonymous"></script>
