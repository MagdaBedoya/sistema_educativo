<?php
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$piso = $_POST['piso'];
$numero = $_POST['numero'];
$sesion = $_POST['sesion'];

$sql = "UPDATE aula SET a_nombre = ?, a_piso = ?, a_numero = ?, a_sesion = ? WHERE a_id = ? ";
$ejecutar = $pdo->prepare($sql);
$ejecutar->execute(array(strtoupper($nombre), $piso, $numero, strtoupper($sesion), $id));
echo '<script language="javascript">alert("Actualizacion exitosa");</script>';
Conexion::desconectar();
