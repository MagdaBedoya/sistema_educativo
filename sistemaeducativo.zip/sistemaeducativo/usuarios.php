        <?php include_once 'head.php' ?>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $accion = $_POST['accion'];
            if ($accion == 'agregar') {
                include_once 'usuarioagregar.php';
            } else if ($accion == 'editar') {
                $id = $_POST['id'];  
                if($usuarioid == $id){
                   include_once 'usuarioactualizar.php';
                   include_once 'salir.php';
                }else{
                 include_once 'usuarioactualizar.php';

                }
            } else if ($accion == 'eliminar') {
                $id = $_POST['id'];          
                if($usuarioid == $id){
                    echo '<script language="javascript">alert("Usted mismo no se puede eliminar");</script>';
                }else{
                    $eliminar = "DELETE FROM usuario WHERE u_id = ?";
                    $ejecutar = $pdo->prepare($eliminar);
                    $ejecutar->execute(array($id));
                    echo '<script language="javascript">alert("Eliminacion Exitosa");</script>';
                    Conexion::desconectar();
                }

                  
                
            }
        }
        ?>

        <body class="sb-nav-fixed">
            <?php include_once 'menuadmin.php' ?>
            <div id="layoutSidenav_content">
                <main>
                    <br/>
                    <div class="container">
                       

                       <!-- AGREGAR -->
                                <div class="modal fade" id="agregar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content ">
                                            <div class="modal-header text-white bg-warning">
                                                <h5 class="modal-title" id="agregar">Registrar Nueva Información</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form  ROLE="FORM" METHOD="POST" ACTION="">
                                                    <input type="hidden" class="form-control" id="accion" name="accion"  value="agregar">


                                                    <div class="row">
                                                     <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label  class="form-label">Apellidos</label>
                                                                <input type="text" class="form-control form-control-sm" id="apellidos" name="apellidos" placeholder="Apellidos Completos" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Nombres</label>
                                                                <input type="text" class="form-control form-control-sm" id="nombres" name="nombres" placeholder="Nombres Completos" required>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div class="row">
                                                        <div class="col-md-2"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Sexo</label>
                                        <select class="form-control  form-control-sm" name="sexo" id="sexo" required>
                                            <?php
                                            $sexo = array("M","F");
                                            foreach ($sexo as $i => $valor) {
                                                ?>
                                                <option value="<?php echo $sexo[$i] ?>">
                                                    <?php echo $sexo[$i] ?>
                                                </option>
                                                <?php
                                            }
                                            ?>

                                        </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-10"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Correo</label>
                                                                <input type="email" class="form-control form-control-sm" id="correo" name="correo" placeholder="Ingrese Correo" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                


                                                    <div class="row">
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Rol</label>
                                        <select class="form-control  form-control-sm" name="rol" id="rol" required>
                                            <?php
                                            $rol = array("ADMINISTRADOR", "RECTOR(A)", "COORDINADOR(A)","SECRETARIA(O)");
                                            foreach ($rol as $i => $valor) {
                                                ?>
                                                <option value="<?php echo $rol[$i] ?>">
                                                    <?php echo $rol[$i] ?>
                                                </option>
                                                <?php
                                            }
                                            ?>

                                        </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Contraseña</label>
                                                                <input type="password" class="form-control form-control-sm" id="contrasena" name="contrasena" placeholder="Ingrese Contraseña" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                
                                                    <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        <div class="card">
                            <div class="card-header text-white bg-black">
                                <h5>USUARIOS</h5>
                            </div>
                            <div class="card-header text-white bg-warning">
                                <strong>Tabla Usuarios &nbsp;&nbsp;<button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#agregar"><i class="fas fa-user-plus"></i>&nbsp; Agregar</button></strong>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="display table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Apellidos y Nombres</th>
                                            <th>Sexo</th>
                                            <th>Correo</th>
                                            <th>Rol</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Apellidos y Nombres</th>
                                            <th>Sexo</th>
                                            <th>Correo</th>
                                            <th>Rol</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $informacion = 'SELECT * FROM usuario ORDER BY u_id DESC;';
                                        foreach ($pdo->query($informacion) as $dato) {
                                            ?>
                                            <tr>
                                                <td><?php echo $dato['u_apellidos']." ".$dato['u_nombres'] ?></td>
                                                <td><?php echo $dato['u_sexo'] ?></td>
                                                 <td><?php echo $dato['u_correo'] ?></td>
                                                 <td><?php echo $dato['u_rol'] ?></td>

                                        <td>
                                        <center><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEditar<?php echo $dato['u_id'] ?>" >
                                                <i class="fas fa-user-edit"></i>
                                            </button></center> 
                                        <div class="modal fade" id="exampleModalEditar<?php echo $dato['u_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header text-white bg-warning">
                                                        <h5 class="modal-title">Actualizar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST" ACTION="">

                                                            <input type="hidden" class="form-control" id="accion" name="accion"  value="editar">
                                                            <input type="hidden" class="form-control form-control-sm" id="id" name="id" value = "<?php echo!empty($dato['u_id']) ? $dato['u_id'] : ''; ?>"  required>


                                                            <div class="row">
                                                               <div class="col-md-6"> 
                                                                    <div class="mb-3">
                                                                        <label  class="form-label">Apellidos</label>
                                                                        <input type="text" class="form-control form-control-sm" id="apellidos" name="apellidos" placeholder="Apellidos Completos" value = "<?php echo!empty($dato['u_apellidos']) ? $dato['u_apellidos'] : ''; ?>" required>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6"> 
                                                                    <div class="mb-3">
                                                                        <label class="form-label">Nombres</label>
                                                                        <input type="text" class="form-control form-control-sm" id="nombres" name="nombres" placeholder="Nombres Completos" value = "<?php echo!empty($dato['u_nombres']) ? $dato['u_nombres'] : ''; ?>" required>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                              <div class="row">
                                                        <div class="col-md-2"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Sexo</label>
                                        <select class="form-control  form-control-sm" name="sexo" id="sexo" required>
                                                        <?php
                                                        $sexo = array("M", "F");
                                                        foreach ($sexo as $i => $value) {
                                                            if ($sexo[$i] == $dato['u_sexo']) {
                                                                ?>
                                                                <option value="<?php echo $sexo[$i] ?>" selected><?php echo $sexo[$i] ?></option>
                                                            <?php } else { ?>
                                                                <option value="<?php echo $sexo[$i] ?>"> <?php echo $sexo[$i] ?></option>
                                                            <?php }
                                                        } ?>
                                                    </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-10"> 
                                                            <div class="mb-3">
                                                    <label  class="form-label">Correo</label>
                                                    <input type="hidden" class="form-control form-control-sm" id="correoviejo" name="correoviejo" value = "<?php echo!empty($dato['u_correo']) ? $dato['u_correo'] : ''; ?>"  required>

                                                    <input type="email" class="form-control form-control-sm" id="correo" name="correo" placeholder="Ingrese Correo" value = "<?php echo!empty($dato['u_correo']) ? $dato['u_correo'] : ''; ?>"  required>
                                                </div>
                                                        </div>
                                                    </div>

                                                     <div class="row">
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Rol</label>
                                        <select class="form-control  form-control-sm" name="rol" id="rol" required>
                                            <?php
                                            $rol = array("ADMINISTRADOR", "RECTOR(A)", "COORDINADOR(A)","SECRETARIA(O)");
                                              foreach ($rol as $i => $value) {
                                                            if ($rol[$i] == $dato['u_rol']) {
                                                                ?>
                                                                <option value="<?php echo $rol[$i] ?>" selected><?php echo $rol[$i] ?></option>
                                                            <?php } else { ?>
                                                                <option value="<?php echo $rol[$i] ?>"> <?php echo $rol[$i] ?></option>
                                                            <?php }
                                                        } ?>

                                        </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Contraseña</label>
                                                                <input type="password" class="form-control form-control-sm" id="contrasena" name="contrasena" placeholder="Ingrese Contraseña" value = "<?php echo!empty($dato['u_contrasena']) ? $dato['u_contrasena'] : ''; ?>"  required>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    
                                                            <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        <!-- ELIMININAR  -->
                                        <td>
                                        <center> <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEliminar<?php echo $dato['u_id'] ?>">
                                                <i class="fas fa-user-times"></i>
                                            </button></center>
                                        <div class="modal fade" id="exampleModalEliminar<?php echo $dato['u_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-warning text-white">
                                                        <h5 class="modal-title">Eliminar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST"  ACTION="">
                                                            <input type="hidden" class="form-control" id="accion" name="accion" value = "eliminar"  />
                                                            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo!empty($dato['u_id']) ? $dato['u_id'] : ''; ?>""  />
                                                            <h4>¿Desea eliminar la información de: <?php echo $dato['u_nombres']." ".$dato['u_apellidos'] ?></h4>
                                                            <br/>
                                                            <div class="form__button__container" >
                                                                <button type="submit" class="btn btn-warning">Eliminar</button>
                                                            </div>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        </tr>
                                    <?php } ?>  


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                   

                </main>
                <?php include_once 'footer.php' ?>
            </div>
        </div>


        </body>
        </html>



        <script src="js/simple-datatables.js" crossorigin="anonymous"></script>
