<?php

$grado = $_POST['grado'];
$aula = $_POST['aula'];
$sesion = $_POST['sesion'];
$vacante = $_POST['vacante'];

$sql = "INSERT INTO grado (g_grado, g_aulafk, g_sesion, g_vacante) VALUES (?, ?, ?, ?)";
$ejecutar = $pdo->prepare($sql);
$ejecutar->execute(array(strtoupper($grado), $aula,strtoupper($sesion), $vacante));
echo '<script language="javascript">alert("Registro Exitoso");</script>';
Conexion::desconectar();
    
?>