<?php
include_once 'configuracion/conexion.php';
$pdo = Conexion::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    session_start(); // allows us to retrieve our key form the session

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $usuario = $_POST['usuario'];
        $contrasena = $_POST['contrasena'];

        $sql = "SELECT COUNT(*) FROM usuario WHERE u_correo = '$usuario' AND u_contrasena  = '$contrasena'";
        $query = $pdo->query($sql);
        $cantidad = $query->fetchColumn();

        if ($cantidad == 0) {
            echo '<script language="javascript">alert("Usuario y/o contrasena no registrado");</script>';
        } else {

            $sql = "SELECT * FROM usuario WHERE u_correo = ? AND u_contrasena = ? ";
            echo $sql;
            $ejecutar = $pdo->prepare($sql);
            $ejecutar->execute(array($usuario, $contrasena));
            $dato = $ejecutar->fetch(PDO::FETCH_ASSOC);
            $_SESSION['permitido'] = 'SI';
            $_SESSION['usuario'] = $dato['u_id'];
            header("Location: admin.php");
            Conexion::desconectar();

        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="shortcut icon" href="imagen/logo.png">
        <title>Sistema Educativo</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="fontawesome/css/all.css" rel="stylesheet" />
        <link href="css/bootstrap.min.css" rel="stylesheet" />
        <script src="fontawesome/js/all.js" crossorigin="anonymous"></script>
    </head>

    
    <style>
   
        .nav-link:hover{
            background-color: #ffc107;
            color: black;
        }
        .nav-link{
            color: white;
        }
    </style>
    <body>
        <br/><br/>


                  
                    <div class="modal-body">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header text-white bg-warning" >
                                        <h3 class="text-center font-weight-light my-4">SISTEMA EDUCATIVO</h3></div>
                                    <div class="card-body">
                                        <h5>Iniciar Sesión para continuar</h5>
                                        <form ROLE="FORM" METHOD="POST" ACTION="">
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="usuario" name="usuario"  type="text" placeholder="Correo Electronico" />
                                                <label for="inputEmail">Correo Electronico</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="contrasena"  name="contrasena" type="password" placeholder="Contrasena" />
                                                <label for="inputPassword">Contraseña</label>
                                            </div>

                                            <div class="form-floating mb-3">
                                                <center><button type="submit" class="btn btn-warning">Ingresar</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <center>Iniciar sesi&oacute;n al Sistema Educativo</center>
                                    </div>
                                </div>
                            </div>
                        </div>

                  
                </div>
        
            </div>

        </div>
    </body>
</html>
<script src="js/jquery-3.5.1.min.js"></script>
