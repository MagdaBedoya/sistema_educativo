<?php


$correo = $_POST['correo'];
$apellidos = $_POST['apellidos'];
$nombres = $_POST['nombres'];
$sexo = $_POST['sexo'];
$rol = $_POST['rol'];
$contrasena = $_POST['contrasena'];

    $sqlcantidad = "SELECT COUNT(*) FROM usuario WHERE u_correo = '" . $correo . "'";
    $query = $pdo->query($sqlcantidad);
    $cantidad = $query->fetchColumn();

    if ($cantidad != 0) {
        echo '<script language="javascript">alert("El Usuario ya se encuentra registrado");</script>';
    } else {

        $sql = "INSERT INTO usuario( u_apellidos, u_nombres, u_sexo, u_correo, u_rol, u_contrasena) VALUES (?, ?, ?, ?, ?, ?)";
        $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array(strtoupper($apellidos), strtoupper($nombres), $sexo,strtolower($correo), $rol, $contrasena));
        echo '<script language="javascript">alert("Registro Exitoso");</script>';
        Conexion::desconectar();
    }

?>