<?php


$codigo = $_POST['codigo'];
$docente = $_POST['docente'];
$materia = $_POST['materia'];


    $sqlcantidad = "SELECT COUNT(*) FROM materias WHERE m_codigo = '" . $codigo . "'";
    $query = $pdo->query($sqlcantidad);
    $cantidad = $query->fetchColumn();

    if ($cantidad != 0) {
        echo '<script language="javascript">alert("El codigo ya se encuentra registrado");</script>';
    } else {

        $sql = "INSERT INTO materias(m_codigo, m_docentefk, m_materia) VALUES (?, ?, ?)";
        $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array(strtoupper($codigo), $docente,strtoupper($materia)));
        echo '<script language="javascript">alert("Registro Exitoso");</script>';
        Conexion::desconectar();
    }

?>