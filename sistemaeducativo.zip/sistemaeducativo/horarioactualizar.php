<?php

$id = $_POST['id'];
$grado = $_POST['grado'];
$materia = $_POST['materia'];
$dia = $_POST['dia'];
$hora = $_POST['hora'];

$sql = "UPDATE horarios SET  h_gradofk = ?, h_materiafk = ?, h_dia = ?, h_hora = ? WHERE h_id  = ?";
$ejecutar = $pdo->prepare($sql);
$ejecutar->execute(array($grado, $materia, $dia, $hora, $id));
echo '<script language="javascript">alert("Actualizacion Exitosa");</script>';
Conexion::desconectar();

?>