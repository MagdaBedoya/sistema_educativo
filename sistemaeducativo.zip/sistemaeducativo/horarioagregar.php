<?php


$grado = $_POST['grado'];
$materia = $_POST['materia'];
$dia = $_POST['dia'];
$hora = $_POST['hora'];


$sql = "INSERT INTO horarios( h_gradofk, h_materiafk, h_dia, h_hora)  VALUES (?, ?, ?, ?)";
$ejecutar = $pdo->prepare($sql);
$ejecutar->execute(array($grado, $materia, $dia, $hora));
echo '<script language="javascript">alert("Registro Exitoso");</script>';
Conexion::desconectar();


?>