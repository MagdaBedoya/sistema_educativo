<?php
$id = $_POST['id'];
$correo = $_POST['correo'];
$correoviejo = $_POST['correoviejo'];
$apellidos = $_POST['apellidos'];
$nombres = $_POST['nombres'];
$sexo = $_POST['sexo'];
$rol = $_POST['rol'];
$contrasena = $_POST['contrasena'];


function validardato($correo, $correoviejo)
{
    if ($correo != $correoviejo) {
        $cantidad = 1;
    } else {
        $cantidad = 0;
    }
    return $cantidad;
}

$Validar = validardato($correo, $correoviejo);

$sqlcantidad = "SELECT COUNT(*) FROM usuario WHERE u_correo = '" . $correo . "'";
$query = $pdo->query($sqlcantidad);
$cantidad = $query->fetchColumn();
$sql = "UPDATE usuario SET u_apellidos = ?, u_nombres = ?, u_sexo = ?, u_correo = ?, u_rol = ?, u_contrasena = ? WHERE u_id = ?";

if ($Validar == 1) {

    if ($cantidad != 0) {
        echo '<script language="javascript">alert("El correo del usuario ya se encuentra registrada");</script>';
    } else {
        $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array(strtoupper($apellidos), strtoupper($nombres), $sexo, strtolower($correo), $rol, $contrasena, $id));
        echo '<script language="javascript">alert("Actualizacion exitosa con correo nuevo");</script>';
        Conexion::desconectar();
    }
} else {

    $ejecutar = $pdo->prepare($sql);
     $ejecutar->execute(array(strtoupper($apellidos), strtoupper($nombres), $sexo,strtolower($correoviejo), $rol, $contrasena, $id));
    echo '<script language="javascript">alert("Actualizacion exitosa");</script>';

    Conexion::desconectar();
}
