<?php
$id = $_POST['id'];
$codigo = $_POST['codigo'];
$codigoviejo = $_POST['codigoviejo'];
$docente = $_POST['docente'];
$materia = $_POST['materia'];

function validardato($codigo, $codigoviejo)
{
    if ($codigo != $codigoviejo) {
        $cantidad = 1;
    } else {
        $cantidad = 0;
    }
    return $cantidad;
}

$Validar = validardato($codigo, $codigoviejo);

    $sqlcantidad = "SELECT COUNT(*) FROM materias WHERE m_codigo = '" . $codigo . "'";
$query = $pdo->query($sqlcantidad);
$cantidad = $query->fetchColumn();
$sql = "UPDATE materias SET m_codigo = ?, m_docentefk = ?, m_materia  = ? WHERE m_id = ?";

if ($Validar == 1) {

    if ($cantidad != 0) {
        echo '<script language="javascript">alert("El codigo ya se encuentra registrado");</script>';
    } else {
        $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array(strtoupper($codigo), $docente,strtoupper($materia), $id));
        echo '<script language="javascript">alert("Actualizacion exitosa con codigo nuevo");</script>';
        Conexion::desconectar();
    }
} else {

    $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array(strtoupper($codigoviejo), $docente,strtoupper($materia), $id));
    echo '<script language="javascript">alert("Actualizacion exitosa");</script>';

    Conexion::desconectar();
}
