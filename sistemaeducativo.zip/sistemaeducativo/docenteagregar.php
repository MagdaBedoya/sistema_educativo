<?php


$identificacion = $_POST['identificacion'];
$apellidos = $_POST['apellidos'];
$nombres = $_POST['nombres'];
$sexo = $_POST['sexo'];
$contrasena = $_POST['contrasena'];

    $sqlcantidad = "SELECT COUNT(*) FROM docente WHERE d_identificacion = " . $identificacion . "";
    $query = $pdo->query($sqlcantidad);
    $cantidad = $query->fetchColumn();

    if ($cantidad != 0) {
        echo '<script language="javascript">alert("El Docente ya se encuentra registrado");</script>';
    } else {

        $sql = "INSERT INTO docente (d_identificacion, d_apellidos, d_nombres, d_sexo, d_contrasena) VALUES (?, ?, ?, ?, ?)";
        $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array($identificacion,strtoupper($apellidos), strtoupper($nombres), $sexo, $contrasena));
        echo '<script language="javascript">alert("Registro Exitoso");</script>';
        Conexion::desconectar();
    }

?>