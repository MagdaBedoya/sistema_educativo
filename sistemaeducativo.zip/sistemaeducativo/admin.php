<?php include_once 'head.php'; ?>
<body class="sb-nav-fixed">
    <?php include_once 'menuadmin.php'; ?>


    <div id="layoutSidenav_content">
        <main>
            <br/>
            <div class="container">
                <div class="card ">
                    <div class="card-header text-white bg-warning">
                        <strong>BINEVENIDO (A)</strong>
                    </div>
                    <div class="card-body">
                        <center>
                            <div class="card" style="width: 18rem;">                     


                               <img src="imagen/logo.png" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $usuarionombres . " " . $usuarioapellidos . "" ?></h5>
                                </div>
                            </div>
                        </center>

                    </div>
                </div>
            </div>
        </main>
        <?php include_once 'footer.php' ?>
    </div>
</div>


</body>
</html>
<script src="js/jquery-3.5.1.min.js"></script>