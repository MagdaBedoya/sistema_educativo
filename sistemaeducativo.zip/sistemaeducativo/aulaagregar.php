<?php

$nombre = $_POST['nombre'];
$piso = $_POST['piso'];
$numero = $_POST['numero'];
$sesion = $_POST['sesion'];

$sql = "INSERT INTO aula( a_nombre, a_piso, a_numero, a_sesion) VALUES (?, ?, ?, ?)";
$ejecutar = $pdo->prepare($sql);
$ejecutar->execute(array(strtoupper($nombre), $piso, $numero, strtoupper($sesion)));
echo '<script language="javascript">alert("Registro Exitoso");</script>';
Conexion::desconectar();
    
?>