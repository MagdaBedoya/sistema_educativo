<!--- BANNER -->
<nav class="sb-topnav navbar navbar-expand navbar-dark bg-secondary">
    <a class="navbar-brand ps-3" href="admin.php"> <?php echo $usuarionombres  ?> &nbsp; &nbsp; <i class="fas fa-user fa-fw"></i></a>
    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
        <h6 style="color: white;">Bienvenido(a): <?php echo $usuarionombres . " " . $usuarioapellidos ?></h6>
    </form>

</nav>
<!--- MENU -->
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav bg-black text-white" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <a class="nav-link" href="admin.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-home-alt"></i></div>
                        Inicio
                    </a>
                    <a class="nav-link" href="usuarios.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        Usuarios
                    </a>
                   
                    <a class="nav-link" href="matriculas.php">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-list"></i></div>
                        Matriculas
                    </a>

                    
                    <a class="nav-link" href="horarios.php">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-clock"></i></div>
                       Horarios
                    </a>

                     <a class="nav-link" href="docentes.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        Docentes
                    </a>

                      <a class="nav-link" href="materias.php">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-book"></i></div>
                        Materias
                    </a>

                    <a class="nav-link" href="grados.php">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-list-ol"></i></div>
                        Grados
                    </a>

                     <a class="nav-link" href="aulas.php">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-building-columns"></i></div>
                        Aulas
                    </a>
                   
                    <a class="nav-link" href="salir.php">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-power-off"></i></div>
                        Salir
                    </a>
                </div>
            </div>

        </nav>
    </div>

