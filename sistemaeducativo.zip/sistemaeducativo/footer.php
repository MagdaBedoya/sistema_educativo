<footer class="py-4  mt-auto" style="background-color: #ffc107;color:black; font-weight: bold;">
    <div class="container-fluid px-4">
            <center><div >Copyright &copy; Sistema Educativo 2023</div></center>
        
    </div>
</footer>
<script src="js/bootstrap.bundle.min.js" ></script>
<script src="js/scripts.js"></script>
<script src="js/datatables-simple-demo.js"></script>
