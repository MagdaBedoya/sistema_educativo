<?php
$id = $_POST['id'];
$identificacion = $_POST['identificacion'];
$identificacionvieja = $_POST['identificacionvieja'];
$apellidos = $_POST['apellidos'];
$nombres = $_POST['nombres'];
$sexo = $_POST['sexo'];
$grado = $_POST['grado'];


function validardato($identificacion, $identificacionvieja)
{
    if ($identificacion != $identificacionvieja) {
        $cantidad = 1;
    } else {
        $cantidad = 0;
    }
    return $cantidad;
}

$Validar = validardato($identificacion, $identificacionvieja);

$sqlcantidad = "SELECT COUNT(*) FROM matricula WHERE m_identificacion = " . $identificacion . "";
$query = $pdo->query($sqlcantidad);
$cantidad = $query->fetchColumn();
$sql = "UPDATE matricula SET m_identificacion = ?, m_apellidos = ?, m_nombres = ?, m_gradofk = ?, m_sexo = ? WHERE m_id = ?";

if ($Validar == 1) {

    if ($cantidad != 0) {
        echo '<script language="javascript">alert("La identificacion del estudiante ya se encuentra registrada");</script>';
    } else {
        $ejecutar = $pdo->prepare($sql);
        $ejecutar->execute(array($identificacion,strtoupper($apellidos), strtoupper($nombres), $grado, $sexo, $id));
        echo '<script language="javascript">alert("Actualizacion exitosa con identificacion nuevo");</script>';
        Conexion::desconectar();
    }
} else {

    $ejecutar = $pdo->prepare($sql);
    $ejecutar->execute(array($identificacionvieja,strtoupper($apellidos), strtoupper($nombres), $grado, $sexo, $id)); 
    echo '<script language="javascript">alert("Actualizacion exitosa");</script>';

    Conexion::desconectar();
}
