        <?php include_once 'head.php' ?>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $accion = $_POST['accion'];
            if ($accion == 'agregar') {
                include_once 'matriculaagregar.php';
            } else if ($accion == 'editar') {
                include_once 'matriculaactualizar.php';
            } else if ($accion == 'eliminar') {
                
                $id = $_POST['id'];            
                $eliminar = "DELETE FROM matricula WHERE m_id = ?";
                $ejecutar = $pdo->prepare($eliminar);
                $ejecutar->execute(array($id));
                echo '<script language="javascript">alert("Eliminacion Exitosa");</script>';
                Conexion::desconectar();
                
            }
        }
        ?>

        <body class="sb-nav-fixed">
            <?php include_once 'menuadmin.php' ?>
            <div id="layoutSidenav_content">
                <main>
                    <br/>
                    <div class="container">
                       

                       <!-- AGREGAR -->
                                <div class="modal fade" id="agregar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content ">
                                            <div class="modal-header text-white bg-warning">
                                                <h5 class="modal-title" id="agregar">Registrar Nueva Información</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form  ROLE="FORM" METHOD="POST" ACTION="">
                                                    <input type="hidden" class="form-control" id="accion" name="accion"  value="agregar">


                                                    <div class="row">
                                                     <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label  class="form-label">Apellidos</label>
                                                                <input type="text" class="form-control form-control-sm" id="apellidos" name="apellidos" placeholder="Apellidos Completos" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Nombres</label>
                                                                <input type="text" class="form-control form-control-sm" id="nombres" name="nombres" placeholder="Nombres Completos" required>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div class="row">
                                                        <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Identificación</label>
                                                                <input type="number" class="form-control form-control-sm" id="identificacion" name="identificacion" placeholder="Indentificación Completa" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Grado</label>
                                        <select class="form-control  form-control-sm" name="grado" id="grado" required>
                                            <?php
                                            $grados = 'SELECT * FROM grado ORDER BY g_id ASC;';
                                                            foreach ($pdo->query($grados) as $dato) {  
                                                            ?>
                                                            <option value="<?php echo $dato['g_id'] ?>"> <?php echo $dato['g_grado'] ?></option>
                                                             <?php
                                                         }
                                                         ?>


                                        </select>
                                                            </div>
                                                        </div>
                                                       <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Sexo</label>
                                        <select class="form-control  form-control-sm" name="sexo" id="sexo" required>
                                            <?php
                                            $sexo = array("M", "F");
                                            foreach ($sexo as $i => $valor) {
                                                ?>
                                                <option value="<?php echo $sexo[$i] ?>">
                                                    <?php echo $sexo[$i] ?>
                                                </option>
                                                <?php
                                            }
                                            ?>

                                        </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                
                                                    <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        <div class="card">
                             <div class="card-header text-white bg-black">
                                <h5>MATRICULAS</h5>
                            </div>
                            <div class="card-header text-white bg-warning">
                                <strong>Tabla Matriculas &nbsp;&nbsp;<button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#agregar"><i class="fa-solid fa-plus"></i>&nbsp; Agregar</button></strong>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="display table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Código</th>
                                            <th>Apellidos y Nombres</th>
                                            <th>Grado</th>
                                            <th>Sexo</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Código</th>
                                            <th>Apellidos y Nombres</th>
                                            <th>Grado</th>
                                            <th>Sexo</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $informacion = 'SELECT * FROM matricula, grado WHERE m_gradofk = g_id ORDER BY m_id DESC;';
                                        foreach ($pdo->query($informacion) as $dato) {
                                            ?>
                                            <tr>
                                                 <td><?php echo $dato['m_identificacion'] ?></td>
                                                <td><?php echo $dato['m_apellidos']." ".$dato['m_nombres'] ?></td>
                                                <td><?php echo $dato['g_grado']." ".$dato['g_sesion'] ?></td>
                                                 <td><?php echo $dato['m_sexo'] ?></td>

                                        <td>
                                        <center><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEditar<?php echo $dato['m_id'] ?>" >
                                                  <i class="fa-solid fa-pen"></i>
                                            </button></center> 
                                        <div class="modal fade" id="exampleModalEditar<?php echo $dato['m_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header text-white bg-warning">
                                                        <h5 class="modal-title">Actualizar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST" ACTION="">

                                                            <input type="hidden" class="form-control" id="accion" name="accion"  value="editar">
                                                            <input type="hidden" class="form-control form-control-sm" id="id" name="id" value = "<?php echo!empty($dato['m_id']) ? $dato['m_id'] : ''; ?>"  required>


                                                            <div class="row">
                                                               <div class="col-md-6"> 
                                                                    <div class="mb-3">
                                                                        <label  class="form-label">Apellidos</label>
                                                                        <input type="text" class="form-control form-control-sm" id="apellidos" name="apellidos" placeholder="Apellidos Completos" value = "<?php echo!empty($dato['m_apellidos']) ? $dato['m_apellidos'] : ''; ?>" required>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6"> 
                                                                    <div class="mb-3">
                                                                        <label class="form-label">Nombres</label>
                                                                        <input type="text" class="form-control form-control-sm" id="nombres" name="nombres" placeholder="Nombres Completos" value = "<?php echo!empty($dato['m_nombres']) ? $dato['m_nombres'] : ''; ?>" required>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                              <div class="row">
                                                                <div class="col-md-6"> 
                                                            <div class="mb-3">
                                                                <label class="form-label">Identificación</label>
                                                                <input type="hidden" class="form-control form-control-sm" id="identificacionvieja" name="identificacionvieja" placeholder="Indentificación Completa" value = "<?php echo!empty($dato['m_identificacion']) ? $dato['m_identificacion'] : ''; ?>" required>

                                                                <input type="number" class="form-control form-control-sm" id="identificacion" name="identificacion" placeholder="Indentificación Completa" value = "<?php echo!empty($dato['m_identificacion']) ? $dato['m_identificacion'] : ''; ?>" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Grado</label>
                                        <select class="form-control  form-control-sm" name="grado" id="grado" required>
                                             <?php
                                              $grados = 'SELECT * FROM grado ORDER BY g_id ASC;';
                                                                            foreach ($pdo->query($grados) as $datogrado) {
                                                                                if ($dato['m_gradofk'] == $datogrado['g_id']) {?>
                                                                                    <option value="<?php echo $datogrado['g_id'] ?>" selected> <?php echo $datogrado['g_grado'] ?></option>
                                                                                     <?php
                                                                                 } else {
                                                                                 ?>
                                                                                    <option value="<?php echo $datogrado['g_id'] ?>"> <?php echo $datogrado['g_grado'] ?></option>
                                                                                 <?php
                                                                             }
                                                                         }
                                                                         ?>


                                        </select>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-3"> 
                                                            <div class="mb-3">
                                                                 <label for="form-label" class="form-label">Seleccione Sexo</label>
                                        <select class="form-control  form-control-sm" name="sexo" id="sexo" required>
                                                        <?php
                                                        $sexo = array("M", "F");
                                                        foreach ($sexo as $i => $value) {
                                                            if ($sexo[$i] == $dato['g_sexo']) {
                                                                ?>
                                                                <option value="<?php echo $sexo[$i] ?>" selected><?php echo $sexo[$i] ?></option>
                                                            <?php } else { ?>
                                                                <option value="<?php echo $sexo[$i] ?>"> <?php echo $sexo[$i] ?></option>
                                                            <?php }
                                                        } 
                                                        ?>
                                                    </select>
                                                            </div>
                                                        </div>
                                                       
                                                    </div>

                                                                                                    
                                                            <center> <button type="submit" class="btn btn-warning">Guardar</button></center>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        <!-- ELIMININAR  -->
                                        <td>
                                        <center> <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalEliminar<?php echo $dato['m_id'] ?>">
                                               <i class="fa-solid fa-trash"></i>
                                            </button></center>
                                        <div class="modal fade" id="exampleModalEliminar<?php echo $dato['m_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-warning text-white">
                                                        <h5 class="modal-title">Eliminar Información</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form  ROLE="FORM" METHOD="POST"  ACTION="">
                                                            <input type="hidden" class="form-control" id="accion" name="accion" value = "eliminar"  />
                                                            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo!empty($dato['m_id']) ? $dato['m_id'] : ''; ?>""  />
                                                            <h4>¿Desea eliminar la información de: <?php echo $dato['m_nombres']." ".$dato['m_apellidos'] ?></h4>
                                                            <br/>
                                                            <div class="form__button__container" >
                                                                <button type="submit" class="btn btn-warning">Eliminar</button>
                                                            </div>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </td>

                                        </tr>
                                    <?php } ?>  


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                   

                </main>
                <?php include_once 'footer.php' ?>
            </div>
        </div>


        </body>
        </html>



        <script src="js/simple-datatables.js" crossorigin="anonymous"></script>
